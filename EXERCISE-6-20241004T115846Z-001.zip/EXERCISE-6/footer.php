<footer style="height: 70px; width: 100%; background: #333333; display:flex; align-items:center; justify-content:center;">
    <p style="color: white; font-size:1.2rem;">&copy; 2024 Group 1. All rights reserved.</p>
</footer>
</body>
</html>